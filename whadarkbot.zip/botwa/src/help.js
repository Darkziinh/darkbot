const help = (prefix) => {
	return `👾𝗔𝗥𝟭𝟱𝗕𝗢𝗧👾
	
	                
┏━━━°❀ ❬ 𝐒𝐎𝐁𝐑𝐄 ❭ ❀°━━━┓
┃
┏❉ *${prefix}owner*
┣❉ *${prefix}doar*
┗❉ *${prefix}creator*
┃
┣━━━°❀ ❬ 𝐂𝐑𝐈𝐀𝐑 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker* [foto]
┣➥ *${prefix}stickergif* [foto]
┣➥ *${prefix}sticker nobg 
┣➥ *${prefix}thunder* [texto]
┣➥ *${prefix}tsticker* [texto/url]
┃
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts* [texto]
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┣➥ *${prefix}toimg*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}wait* [foto]
┣➥ *${prefix}simi
┣➥ *${prefix}simih*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ 𝐆𝐑𝐔𝐏𝐎 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}getpp*
┣➥ *${prefix}tagall*
┣➥ *${prefix}linkgroup
┣➥ *${prefix}gprofile*
┣➥ *${prefix}setprefix
┣➥ *${prefix}welcome*
┣➥ *${prefix}left*
┃
┣━━━━°❀ ❬ 𝐒𝐎𝐍𝐒 ❭ ❀°━━━━━⊱
┃
┣➥ *salam*
┣➥ *tariksis*
┣➥ *baka*
┣➥ *desah*
┣➥ *goblok*
┣➥ *roti*
┣➥ *welot*
┣➥ *abangjago*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┃╔══╗╔═╗╔══╗╔══╗
┃║╔╗║║╬║╚║║╝║══╣
┃║╠╣║║╗╣╔║║╗╠══║
┃╚╝╚╝╚╩╝╚══╝╚══╝
┃───────────────
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ 𝗙𝗘𝗜𝗧𝗢 𝗣𝗢𝗥  ⃬⃗𝐷𝐴𝑅𝐾⃖  ☔
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help

