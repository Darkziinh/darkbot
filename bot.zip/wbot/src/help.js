const help = (prefix) => {
	return `
╔══✪〘 INFO 〙✪══
║
╠➥ 𝐃𝐀𝐑𝐊 𝐁𝐎𝐓
╠➥ *3.0*
╠➥ 𝐃𝐎𝐍𝐎:  ⃬⃗𝐷𝐴𝑅𝐾⃖  ☔
╠➥ *wa.me/+5517991134416*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 MENU 〙✪══
║
╠➥ *${prefix}sticker*
╠➥ *${prefix}toimg*
╠➥ *${prefix}meme*
╠➥ *${prefix}memeindo*
╠➥ *${prefix}gtts*
╠➥ *${prefix}loli*
╠➥ *${prefix}nsfwloli*
╠➥ *${prefix}url2img*
╠➥ *${prefix}ocr*
╠➥ *${prefix}wait*
╠➥ *${prefix}setprefix*
║
╠══✪〘 OUTROS 〙✪══
║
╠➥ *${prefix}linkgroup*
╠➥ *${prefix}simih [1/0]*
╠➥ *${prefix}marcar*
╠➥ *${prefix}add [@]*
╠➥ *${prefix}kick [@]*
╠➥ *${prefix}promote [@]*
╠➥ *${prefix}demote*
╠➥ *${prefix}listadmins*
╠➥ *${prefix}marcar2*
╠➥ *${prefix}bc [texto]*
╠➥ *${prefix}marcar3*
╠➥ *${prefix}blocklist*
╠➥ *${prefix}block [@]*
╠➥ *${prefix}unblock [@]*
╠➥ *${prefix}clearall*
╠➥ *${prefix}bc [ *texto* ]*
╠➥ *${prefix}welcome [1/0]*
╠➥ *${prefix}clone [@]*
╠➥ *${prefix}darkmenu*
╠➥ *${prefix}dono*
║
╠══✪〘 BASE 〙✪══
║
╠➥ Mhankbar
╠➥ Espero que tenham gostado ❤️
║
╚═〘 𝐃𝐀𝐑𝐊 𝐁𝐎𝐓 〙`
}

exports.help = help






