const help1 = (prefix) => {

	return `
╔══✪〘 INFO 〙✪══
║
╠➥ 𝐃𝐀𝐑𝐊 𝐁𝐎𝐓
╠➥ *3.0*
╠➥ 𝐃𝐎𝐍𝐎:  ⃬⃗𝐷𝐴𝑅𝐾⃖  ☔
╠➥ *wa.me/+5517991134416*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 MENU1 〙✪══
║
╠➥ *${prefix}dono*
╠➥ *${prefix}text3d*
╠➥ *${prefix}owner*
╠➥ *${prefix}infogc*
╠➥ *${prefix}infogroup*
╠➥ *${prefix}fakereplay*
╠➥ *${prefix}lionlogo*
╠➥ *${prefix}wolflogo*
╠➥ *${prefix}texteng*
╠➥ *${prefix}testsky*
╠➥ *${prefix}textblue*
╠➥ *${prefix}textdark*
╠➥ *${prefix}firetext*
╠➥ *${prefix}water*
╠➥ *${prefix}rtext*
╠➥ *${prefix}glitch*
╠➥ *${prefix}party*
╠➥ *${prefix}ninjalogo*
╠➥ *${prefix}teste*
╠➥ *${prefix}teste2*
╠➥ *${prefix}stiltext*
╠➥ *${prefix}thunder*
╠➥ *${prefix}lovemaker*
╠➥ *${prefix}marvellogo*
╠➥ *${prefix}snowrite*
╠➥ *${prefix}testing*
╠➥ *${prefix}ramaljadian*
╠➥ *${prefix}primbonjodoh*
╠➥ *${prefix}phlogo*
╠➥ *${prefix}galaxtext*
╠➥ *${prefix}quotemaker*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
║
╠══✪〘 *FIM* 〙✪══

════════════════════
*DARK YT* 🤗
*Digite ${prefix}dono para mais info*
════════════════════`
}
exports.help1 = help1

