const help1 = (prefix) => {
	return `
*COMANDOS SERAM COLOCADOS AINDA* `
}

exports.help = help







	